<?php
// PHP Hotel Booking All Rights Reserved
// A software product of NetArt Media, All Rights Reserved
// Find out more about our products and services on:
// http://www.netartmedia.net
// Released under the MIT license
?>; <?php exit;?>

[login]
admin_user = "administrator"
admin_password = "da1907216877e31462c14b35db67de32"

[website]
seo_urls = "0"
currency = "$"
date_format = "d/m/Y"
results_per_page = "10"
admin_email = "info@domain.com"
use_captcha_images = "1"

[email]
smtp_server = "localhost"
smtp_user = ""
smtp_password = ""
smtp_port = "25"

